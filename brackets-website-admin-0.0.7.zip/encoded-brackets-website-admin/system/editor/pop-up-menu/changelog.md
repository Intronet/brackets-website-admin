# Changelog Pop menu Brackets

## v 1.1.1

* Fix a small problem
* PR 2
* PR 1
* PR 3

## v 2.0.1

* Fix a small problem in Italian language
* PR 4
* PR 5

## v 2.1.2

* Added pt-br strings
* PR 6
* PR 7
* PR 8

## v 2.2.5

* PR 9
* PR 10
* PR 13
* Fix any problem in JP language

## v 3.2.8

* PR 14
* PR 15
* PR 16
* PR 17
* Fix any small problems
* Add "UNDO" 

## v 3.3.8

* Update all languages

## v 4.0.0

* Fix some errors
* Add Sync Spit View 
* Update README 
* Update root and Italian language
